package com.capgemini.test;

public class AdminDAOImplTest {

}
