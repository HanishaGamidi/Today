package com.capgemini.main;

import java.util.Scanner;

import com.capgemini.beans.Hotel;
import com.capgemini.beans.RoomDetails;
import com.capgemini.dao.AdminDAO;
import com.capgemini.dao.AdminDAOImpl;
import com.capgemini.dao.UserDAO;
import com.capgemini.dao.UserDAOImpl;
import com.capgemini.exception.HotelException;
import com.capgemini.service.AdminService;
import com.capgemini.service.AdminServiceImpl;
import com.capgemini.service.UserService;
import com.capgemini.service.UserServiceImpl;

public class HotelMain {
	
	public static void main(String[] args)throws HotelException
	{
		Scanner sc = new Scanner(System.in);
	
	  while(true)
	  {
		  
		    System.out.println("Hotel Bookings Management System\n");
		    System.out.println("________________________________\n");
			System.out.println("1. Login (User/Admin)\n");
			System.out.println("2. Exit\n");
			System.out.println("Enter your choice:\n");
			AdminService admindao = new AdminServiceImpl();
	        UserService userdao = new UserServiceImpl();
			int choice = sc.nextInt();
			
			if(choice!=2) {
			switch(choice)
			{
			
		   
		     case 1:  
		    	    System.out.println("Login ID: \n");
			        String user_id = sc.next(); 
			        
			        System.out.println("Password: \n");
			        String password = sc.next();
			        
			       String role = admindao.userVerification(user_id, password);
			        
			        if(role.equals("User"))
			        { 
			        	while(true){
			        		
			        	System.out.println("\n-----------User Portal------------");
			        	System.out.println("\n 1.View List of Hotels \n 2.Book Rooms\n 3.logout");
			            System.out.println("\n Enter Choice: \n");
			            
			            int opt= sc.nextInt();
			            if(opt!=3){
			            switch(opt){
			            case 1: System.out.println("\n List of Hotels ");
		                        userdao.retrieveHotelDetails();
		                   
			           case 2: 
			                   System.out.println("\n Enter room Id:");
			                   String room_id= sc.next();
			                   System.out.println("\n User Id:");
			                   String user_id1= sc.next();
			                   System.out.println("\n Enter No of Days:");
			                   int no_of_days=sc.nextInt();
			                   System.out.println("\n Booking From:");
			                   String booking_from = sc.next();
			                   System.out.println("\n Booking To:");
			                   String booking_to = sc.next();
			                   System.out.println("\n Enter No of Adults:");
			                   int no_of_adults = sc.nextInt();
			                   System.out.println("\n Enter No of Children:");
			                   int no_of_children = sc.nextInt();
			                   double amount=userdao.calculateAmount(room_id,no_of_days);
			                   System.out.println("\n Amount:" +amount );
			                   userdao.bookRooms(room_id,user_id1,booking_from,booking_to,no_of_adults,no_of_children,amount);
			                   break;
			                   default: System.out.println("\n invalid option");
			            }
			            }
			            else 
			        	{
			        		System.out.println("\n Logged out successfully...\n"); 
			                break;
			             }      
			            
			        	}
			        } else if(role.equals("Admin"))
			        {
			        	while(true)
	                    {
			            System.out.println("\n------------ADMIN Portal--------------");
			        	System.out.println("\n 1.Add Hotels or Rooms\n 2.Update Hotels or Rooms\n 3.Delete Hotels or Rooms");
			        	System.out.println("\n 4.View Reports \n 5.Logout");
			        	int opt2= sc.nextInt();
			        	if(opt2!=5)
			        	{
			        	switch(opt2){
			        	case 1: System.out.println("\n Hotel Id: ");
			        	        String hotel_id=sc.next();
			        	        System.out.println("\n City: ");
			        	        String city= sc.next();
			        	        System.out.println("\n Hotel Name: ");
			        	        String hotel_name= sc.next();
			        	        System.out.println("\n Address: ");
			        	        String address = sc.next();
			        	        System.out.println("\n Description: ");
			        	        String description=sc.next();
			        	        System.out.println("\n Avg_rate_per_night: ");
			        	        double avg_rate_per_night=sc.nextDouble();
			        	        System.out.println("\n Phone_No1: ");
			        	        String phone_no1=sc.next();
			        	        System.out.println("\n Phone_No2: ");
			        	        String phone_no2=sc.next();
			        	        System.out.println("\n Rating: ");
			        	        String rating=sc.next();
			        	        System.out.println("\n Email: ");
			        	        String email=sc.next();
			        	        System.out.println("\n Fax: ");
			        	        String fax=sc.next();
			        	        
			        	        Hotel hotel= new Hotel();
			        	        
			        	        hotel.setHotel_id(hotel_id);
			        	        hotel.setCity(city);
			        	        hotel.setHotel_name(hotel_name);
			        	        hotel.setAddress(address);
			        	        hotel.setDescription(description);
			        	        hotel.setAvg_rate_per_night(avg_rate_per_night);
			        	        hotel.setPhone_no1(phone_no1);
			        	        hotel.setPhone_no2(phone_no2);
			        	        hotel.setRating(rating);
			        	        hotel.setEmail(email);
			        	        hotel.setFax(fax);
			        	        
			        	        System.out.println("\n Hotel Id: ");
			        	        String hotel_id1= sc.next();
			        	        System.out.println("\n Room Id: ");
			        	        String room_id= sc.next();
			        	        System.out.println("\n Room No: ");
			        	        String room_no= sc.next();
			        	        System.out.println("\n Room Type: ");
			        	        String room_type= sc.next();
			        	        System.out.println("\n Per_night_rate: ");
			        	        double per_night_rate= sc.nextDouble();
			        	        System.out.println("\n Availability: ");
			        	        String availability= sc.next();
			        	        
			        	        RoomDetails roomdetails= new RoomDetails();
			        	        roomdetails.setHotel_id(hotel_id);
			        	        roomdetails.setRoom_id(room_id);
			        	        roomdetails.setRoom_no(room_no);
			        	        roomdetails.setRoom_type(room_type);
			        	        roomdetails.setPer_night_rate(per_night_rate);
			        	        roomdetails.setAvailability(availability);
			        	        admindao.addDetails(hotel, roomdetails);
			        	        break;
			        	        
			        	case 2:  System.out.println("\n enter hotel id to update: ");
   	        		             String hotel_id11= sc.next();
   	        		             System.out.println("\n enter room id to update ");
	        	                 String room_id1= sc.next();
	        	                 System.out.println("\n Room no  ");
	        	                 String room_no1= sc.next();
	        	                 System.out.println("\n Room type : ");
	        	                 String room_type1= sc.next();
	        	                 System.out.println("\n Per night rate: ");
	        	                 double per_night_rate1= sc.nextDouble();
	        	                 System.out.println("\n Availabilty: ");
	        	                 String availability1= sc.next();
	        	                // admindao.updateDetails(hotel_id11,room_id1,room_no1,room_type1,per_night_rate1,availability1);
	        	                 break; 
			        	case 3:  System.out.println("\n enter hotel id to delete: ");
       		                     String hotel_id2= sc.next();
       		                     System.out.println("\n enter room id to delete: ");
       		                     String room_id11=sc.next();
       		                     int count1 = admindao.countUsers(hotel_id2);
         	                     if(count1==0){
         	        		     admindao.deleteDetails(hotel_id2,room_id11);
 		        	             }else System.out.println("\n Cannot be deleted");
         	                     break;
			        	case 4: System.out.println("\n Enter Booking Id: ");
			        	        String booking_id=sc.next();
			        	        System.out.println("\n Enter User Id: ");
			        	        String user_id1= sc.next();
			        	       // System.out.println("\n Amount: ");
			        	       // String cost= userdao.calculateAmount(user_id, count);
			        	       // admindao.viewReports(booking_id,user_id,amount);
			        	        break;
			        	        
			        	default: System.out.println("\n invalid choice");
			        	   }
			        	}
			        	else 
			        	{
			        		System.out.println("\n Logged out successfully...\n"); break;
			        		
			        	}
	                    }
			   }
			        break;
			        
		     default: System.out.println("\n Invalid Choice");
			}
			}
					
			else 
			{
				System.out.println("\n Exited Portal"); 
				break;
			}
			
		 }
		}
			 
			
	
		
}

		
	

		    		  
		    		
		
			
		

			
			        

	 
