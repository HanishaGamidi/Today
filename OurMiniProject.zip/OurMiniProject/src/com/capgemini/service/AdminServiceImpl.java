package com.capgemini.service;

import com.capgemini.beans.Hotel;
import com.capgemini.beans.RoomDetails;
import com.capgemini.dao.AdminDAO;
import com.capgemini.dao.AdminDAOImpl;
import com.capgemini.exception.HotelException;

public class AdminServiceImpl implements AdminService {
	
	AdminDAO daoref = new AdminDAOImpl();;

	
	public String userVerification(String user_id, String password) throws HotelException {
		return daoref.userVerification(user_id,password);
	}


	public boolean addDetails(Hotel hotel, RoomDetails roomdetails) throws HotelException {
		boolean a= daoref.addDetails(hotel,roomdetails);
		 return a;
	}


	public boolean updateDetails(RoomDetails roomdetails) throws HotelException {
		boolean a= daoref.updateDetails(roomdetails);
		 return a;
	}


	public boolean deleteDetails(String hotel_id,String room_id) throws HotelException {
		boolean a= daoref.deleteDetails(hotel_id,room_id);
		 return a;
	}


	public void viewReports(String booking_id, String user_id, Double amount) throws HotelException {
		daoref.viewReports(booking_id,user_id,amount);
	}


	@Override
	public int countUsers(String booking_id) throws HotelException {
		return daoref.countUsers(booking_id);
	}

}
