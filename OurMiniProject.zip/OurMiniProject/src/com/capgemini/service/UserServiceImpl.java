package com.capgemini.service;

import com.capgemini.dao.UserDAO;
import com.capgemini.dao.UserDAOImpl;
import com.capgemini.exception.HotelException;


public class UserServiceImpl implements UserService{
	
	UserDAO daoref = new UserDAOImpl();

	@Override
	public void retrieveHotelDetails() throws HotelException {
		 daoref.retrieveHotelDetails();
	}

	@Override
	public boolean bookRooms(String room_id, String user_id, String booking_from, String booking_to, int no_of_adults,
			int no_of_children, double amount) throws HotelException {
		return daoref.bookRooms(room_id, user_id,booking_from,booking_to,no_of_adults,
				no_of_children,  amount);
	}
	

	@Override
	public double calculateAmount(String room_id, int no_of_days) throws HotelException {
		return daoref.calculateAmount(room_id,no_of_days);
	}
}
