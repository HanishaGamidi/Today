package com.capgemini.wallet.dao;

import com.capgemini.wallet.bean.Customer;

public interface CustomerDao {
	
	public Customer save(Customer customer);

	public Customer findByMobileNumber(String mobileNumber);

	//public Customer updateCustomerWalletBalance(String mobileNumber,BigDecimal amount);


}
