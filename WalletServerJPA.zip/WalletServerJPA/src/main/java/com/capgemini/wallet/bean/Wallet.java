package com.capgemini.wallet.bean;

import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Wallet {

	@Id
	private BigDecimal balance;
	@OneToMany
    private Set<Transaction> transaction;
    
    
    public Wallet() {
		super();
		
	}
    
	public Wallet(BigDecimal amount) {
		this.balance=amount;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	public Set<Transaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(Set<Transaction> transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}
    
    

}
