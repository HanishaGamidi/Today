
package com.capgemini.wallet.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "CUSTOMER")
public class Customer {
	
        private String customerName;
		
		@Id
		private String mobileNumber;
		
		@OneToOne(cascade=CascadeType.ALL)
	    private Wallet wallet;
	
	
	
	public Customer() {
		super();
	}
	public Customer(String customerName, String mobileNumber, Wallet wallet) {
		super();
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.wallet = wallet;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", mobileNumber=" + mobileNumber + ", wallet=" + wallet + "]";
	}

}
