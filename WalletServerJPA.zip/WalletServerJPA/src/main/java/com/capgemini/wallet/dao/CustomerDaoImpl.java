package com.capgemini.wallet.dao;

import java.util.Map;

import com.capgemini.wallet.bean.Customer;

public class CustomerDaoImpl implements CustomerDao{

private Map<String,Customer> customerData;


	
	public CustomerDaoImpl() {
	super();
	
}

	public CustomerDaoImpl(Map<String, Customer> customerData) 
	{
		super();
		this.customerData = customerData;
	}
    
	public Customer save(Customer customer) {
		if(customerData.containsKey(customer.getMobileNumber()))
		{
			customerData.replace(customer.getMobileNumber(), customer);
		}
		else
			customerData.put(customer.getMobileNumber(), customer);
		return customer;
	}
    public Customer findByMobileNumber(String mobileNumber) {
		
		Customer customer=null;
		customer=customerData.get(mobileNumber);
		return customer;
		
	}
	
    /*@Override
	public Customer updateCustomerWalletBalance(String mobileNumber, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}*/
	
	

}
