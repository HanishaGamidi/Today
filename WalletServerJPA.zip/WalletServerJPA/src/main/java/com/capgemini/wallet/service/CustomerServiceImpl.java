package com.capgemini.wallet.service;

import java.math.BigDecimal;
import com.capgemini.wallet.bean.Customer;
import com.capgemini.wallet.bean.Wallet;
import com.capgemini.wallet.dao.CustomerDao;
import com.capgemini.wallet.exception.InvalidInputException;



public class CustomerServiceImpl implements CustomerService{
	
	private CustomerDao customerDao;
	
	public CustomerServiceImpl() {
		super();

	} 
	
	public CustomerServiceImpl(CustomerDao customerDao) 
	{
		super();
		this.customerDao = customerDao;
	}

	
	
	
	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}


	public Customer createAccount(String customerName,String mobileNumber,BigDecimal amount) throws InvalidInputException {
        Customer customer=null;
		
		if(isValidName(customerName) && isValidMobile(mobileNumber) && isValidamount(amount))
		{
		customer=new Customer(customerName,mobileNumber,new Wallet(amount));
		if(customerDao.findByMobileNumber(mobileNumber) != null)
			throw new InvalidInputException("The account with mobile Number "+ mobileNumber+" is already created");
		customerDao.save(customer);
		}
		
		return customer;	
	}

	@Override
	public Customer fundTransfer(String sourceMobileNumber, String receiverMobileNumber,BigDecimal amount) throws InvalidInputException, InsufficientBalanceException {
		Customer sender = customerDao.findByMobileNumber(sourceMobileNumber);
		Customer receiver = customerDao.findByMobileNumber(receiverMobileNumber);
		Wallet sourceWallet = sender.getWallet();
		Wallet destinationtWallet = receiver.getWallet();
		
		if((sourceWallet != null && destinationtWallet != null) && (sourceWallet.getBalance().compareTo(amount)>=0)){
		
			sourceWallet.setBalance(sourceWallet.getBalance().subtract(amount));
			destinationtWallet.setBalance(destinationtWallet.getBalance().add(amount));
			
			
			sender.setWallet(sourceWallet);
			receiver.setWallet(destinationtWallet);
			
			customerDao.save(sender);
			customerDao.save(receiver);
			return sender;
		}
		
		return null;
	}

	@Override
	public Customer depositAmount(String mobileNumber, BigDecimal amount) throws InvalidInputException {
		Customer customer=null;
		if(isValidMobile(mobileNumber) && isValidamount(amount))
		{
			customer=customerDao.findByMobileNumber(mobileNumber);

			if(customer == null)
				throw new InvalidInputException("There is No Payment wallet account for the Number "+mobileNumber);

			if(amount.equals(new BigDecimal(0)))
				throw new InvalidInputException("Enter Valid Amount to Withdraw");

			BigDecimal balance=customer.getWallet().getBalance().add(amount);
			customer.setWallet(new Wallet(balance));
			customerDao.save(customer);
		}

		return customer;
	}

	

	public Customer showBalance(String mobileNumber) throws InvalidInputException {
		Customer customer=null;
		if(isValidMobile(mobileNumber))
		{
		  customer=customerDao.findByMobileNumber(mobileNumber);
		}
		if(customer == null)
			throw new InvalidInputException("The mobile Number You Entered is Not having Payment Wallet Account");
		return customer;
		

	}

	/*@Override
	public Customer showTransactions(String mobileNumber) {
		// TODO Auto-generated method stub
		return null;
	}*/

	public boolean isValidName(String customerName) throws InvalidInputException 
	{
		if( customerName == null)
			throw new InvalidInputException( "Sorry, Customer Name is null" );
		
		if( customerName.trim().isEmpty() )
			throw new InvalidInputException( "Sorry, customer Name is Empty" );
		
		return true;
	}

	public boolean isValidMobile(String mobileNumber)throws InvalidInputException
	{
		if( mobileNumber == null||  isPhoneNumberInvalid( mobileNumber ))
			throw new InvalidInputException( "Sorry, Phone Number "+mobileNumber+" is invalid"  );
		
		return true;
	}

	public boolean isValidamount(BigDecimal balance)throws InvalidInputException
	{
		if( balance == null || isAmountInvalid( balance ) )
			throw new InvalidInputException( "Balance is invalid" );

		return true;
	}

	public boolean isAmountInvalid(BigDecimal amount) 
	{
		
		if( amount.compareTo(new BigDecimal(0)) < 0) 
		{
			return true;
		}		
		else 
			return false;
	}

	public static boolean isPhoneNumberInvalid( String mobileNumber )
	{
		if(String.valueOf(mobileNumber).matches("[1-9][0-9]{9}")) 
		{
			return false;
		}		
		else 
			return true;
	}
	
}
