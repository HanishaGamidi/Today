package com.capgemini.wallet.service;

	import java.math.BigDecimal;

	import com.capgemini.wallet.bean.Customer;
import com.capgemini.wallet.exception.InvalidInputException;

	public interface CustomerService {
		
		public Customer createAccount(String customerName,String mobileNumber, BigDecimal balance) throws InvalidInputException;
		public Customer fundTransfer(String mobileNumber, String receiverMobileNumber,BigDecimal amount) throws InvalidInputException, InsufficientBalanceException;
		public Customer depositAmount(String mobileNumber, BigDecimal amount) throws InvalidInputException;
		public Customer showBalance(String mobileNumber) throws InvalidInputException;
		//public Customer showTransactions(String mobileNumber);
		
}

