package com.capgemini.wallet.main;

import java.math.BigDecimal;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.capgemini.wallet.bean.Customer;
import com.capgemini.wallet.exception.InvalidInputException;
import com.capgemini.wallet.service.CustomerServiceImpl;
import com.capgemini.wallet.service.InsufficientBalanceException;


public class Client {
	
	
	public static void main(String args[]) throws InvalidInputException, InsufficientBalanceException{
		/*Map<Integer,Customer>customerData = new HashMap<Integer,Customer>();
    	CustomerDao customerDao = new CustomerDaoImpl(customerData);
    	CustomerService customerService = new CustomerServiceImpl(customerDao);*/
    	
    	GenericXmlApplicationContext ctx= new GenericXmlApplicationContext("BeanConfiguration.xml");
    	CustomerServiceImpl customerService=ctx.getBean("service",CustomerServiceImpl.class);
    	//customerService.setCustomerDao(customerDao);
    	
		Customer customer ;

		
		//createAccount
		Customer customer1=customerService.createAccount("Hanisha","9000296666",new BigDecimal(6000));
		System.out.println("Thank you "+customer1.getCustomerName()+"," + " Your account has been created successfully!");
		Customer customer2=customerService.createAccount("Anjani","9100700791",new BigDecimal(5000));
		System.out.println("Thank you "+customer2.getCustomerName()+"," +" Your account has been created successfully!");
		Customer customer3=customerService.createAccount("Roshini","1357908642",new BigDecimal(4000));
		System.out.println("Thank you "+customer3.getCustomerName()+"," + " Your account has been created successfully!");
		Customer customer4=customerService.createAccount("Manisha","1468097536",new BigDecimal(3000));
		System.out.println("Thank you "+customer4.getCustomerName()+ "," +" Your account has been created successfully!");
		Customer customer5=customerService.createAccount("Harini","2123456789",new BigDecimal(2000));
		System.out.println("Thank you "+customer5.getCustomerName()+"," + " Your account has been created successfully!");
		
		
		//showBalance
		customer=customerService.showBalance("9000296666");
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance("9100700791");
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance("1357908642");
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance("1468097536");
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance("2123456789");
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		
		
		/*customer=customerService.showBalance("9012594604");
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance("9100000091");
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance("9866666678");
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());*/
		
		
        //depositAmount
		customer=customerService.depositAmount("9000296666",new BigDecimal(7000));
		System.out.println("Your have successfully deposited... ");
		System.out.println("Now Your Account Balance is "+customer.getWallet().getBalance());
		
		
		
		//fundTransfer
		customerService.createAccount("Ekta", "9000295211",new BigDecimal(3000));
        customerService.fundTransfer("9000296666", "9000295211", new BigDecimal(1500));
        //customerService.showBalance("9000295211");
        System.out.println("Amount Deposited  " +customerService.showBalance("9000295211"));
        System.out.println("Your Current Balance is  " +customerService.showBalance("9000296666"));
		ctx.close();
}

}