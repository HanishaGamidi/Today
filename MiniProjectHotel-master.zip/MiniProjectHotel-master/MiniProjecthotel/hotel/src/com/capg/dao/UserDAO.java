package com.capg.dao;

import com.capg.exception.HotelException;

public interface UserDAO {
	
	public String userVerification (String user_id,String password) throws HotelException;
	public void retrieveHotelDetails() throws HotelException;
	public boolean bookRooms(String room_id,String user_id,String booking_from,String booking_to,int no_of_adults,int no_of_children,double amount) throws HotelException;
	public double calculateAmount(String room_id,int no_of_days)throws HotelException;
	

}
