package com.capg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Logger;

import com.capg.beans.BookingDetails;
import com.capg.beans.Hotel;
import com.capg.beans.RoomDetails;
import com.capg.exception.HotelException;
import com.capg.util.DBUtils;
import com.capg.util.Log4jHTMLLayout;

public class UserDAOImpl implements UserDAO {
	
private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
	
	
	private Connection dbConnection; 

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String userVerification(String user_id, String password) throws HotelException {
		
		String loginQuery = "select * from Users where user_id=?";
		String role= "";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(loginQuery);
			
			
			insertStatement.setString(1, user_id);
			ResultSet result = insertStatement.executeQuery();
			while(result.next())
			{
			String pswd=result.getString(2);
			
			if(pswd.equals(pswd))
			{
				System.out.println("Valid user..");
				log.info("Valid user..");
				 role= result.getString(3);
				 System.out.println(role);
				return role;
			}
			else{
				System.out.println("\n user id or password is incorrect");
			    return null;
			}  
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			log.error(e.getMessage());
	     	throw new HotelException("Login failed...");
			return null;
		}
		return role;
		
	
	}

	@Override
	public void retrieveHotelDetails() throws HotelException {
		
		String selectquery= " select * from Hotel h join RoomDetails r on h.hotel_id=r.hotel_id";
		
		try{
			PreparedStatement insertStatement = dbConnection.prepareStatement(selectquery);
            ResultSet result= insertStatement.executeQuery();
            while(result.next()){
            	
            	String hotel_id=result.getString(1);
            	String city=result.getString(2);
            	String hotel_name=result.getString(3);
            	String address=result.getString(4);
            	String description=result.getString(5);
            	Double avg_rate_per_night=result.getDouble(6);
            	String phone_no1=result.getString(7);
            	String phone_no2=result.getString(8);
                String rating=result.getString(9);
                String email=result.getString(10);
                String fax=result.getString(11);
                String hotel_id1=result.getString(12);
            	String room_id=result.getString(13);
            	String room_no=result.getString(14);
            	String room_type=result.getString(15);
            	Double per_night_rate=result.getDouble(16);
            	String availability=result.getString(17);
            	
                
                 Hotel hotel=new Hotel(hotel);
                 RoomDetails roomdetails=new RoomDetails(roomdetails);
                 
                 hotel.setHotel_id(hotel_id);
                 hotel.setCity(city);
                 hotel.setHotel_name(hotel_name);
                 hotel.setAddress(address);
                 hotel.setDescription(description);
                 hotel.setAvg_rate_per_night(avg_rate_per_night);
                 hotel.setPhone_no1(phone_no1);
                 hotel.setPhone_no2(phone_no2);
                 hotel.setRating(rating);
                 hotel.setEmail(email);
                 hotel.setFax(fax);
          
                 roomdetails.setHotel_id(hotel_id1);
                 roomdetails.setRoom_id(room_id);
                 roomdetails.setRoom_no(room_no);
                 roomdetails.setRoom_type(room_type);
                 roomdetails.setPer_night_rate(per_night_rate);
                 roomdetails.setAvailability(availability);
                 
            
                 System.out.println("\n Hotel Id: "+hotel.getHotel_id());
                 System.out.println("\n City:"+hotel.getCity());
                 System.out.println("\n Hotel Name:"+ hotel.getHotel_name());
                 System.out.println("\n Address:"+ hotel.getAddress());
                 System.out.println("\n Description:"+ hotel.getDescription());
                 System.out.println("\n Average rate per night:"+hotel.getAvg_rate_per_night());
                 System.out.println("\n Phone no1:"+ hotel.getPhone_no1());
                 System.out.println("\n Phone no 2:"+ hotel.getPhone_no2());
                 System.out.println("\n Rating:"+ hotel.getRating());
                 System.out.println("\n Email:"+hotel.getEmail());
                 System.out.println("\n Fax:"+hotel.getFax());
                 System.out.println("\n Hotel Id:"+ roomdetails.getHotel_id());
                 System.out.println("\n Room Id:"+roomdetails.getRoom_id());
                 System.out.println("\n Room no:"+roomdetails.getRoom_no());
                 System.out.println("\n Room Type:"+roomdetails.getRoom_type());
                 System.out.println("\n Per night rate:"+ roomdetails.getPer_night_rate());
                 System.out.println("\n Availability:"+roomdetails.getAvailability());
                 
         
                 }
            }
            catch (SQLException e) {
    			e.printStackTrace();
    			log.error(e.getMessage());
    			throw new HotelException("Failed to retrieve details");
    			
    		}
		
	}
	
	@Override
	public boolean bookRooms(String room_id,String user_id,String booking_from,String booking_to,int no_of_adults,int no_of_children,double amount) throws HotelException
	{
		
	    String insertquery= " insert into BookingDetails values(booking_id_seq.nextval(),?,?,?,?,?,?,?) ";
		
		try{
	        	PreparedStatement insertStatement= dbConnection.prepareStatement(insertquery);
	        	
	        	insertStatement.setString(1, room_id);
				insertStatement.setString(2, user_id);
				insertStatement.setString(3, booking_from);
				insertStatement.setString(4, booking_to);
				insertStatement.setInt(5, no_of_adults);
				insertStatement.setInt(6, no_of_children);
				insertStatement.setDouble(7, amount);
				
				int rows = insertStatement.executeUpdate();
				
				if((rows > 0))
				{
					System.out.println("Booking Confirmed succesfully...");
					log.info("Added a row in db now...");
					return true;
				}
					
					
				else 
					return false;
				
			} catch (SQLException e) {
				e.printStackTrace();
				log.error(e.getMessage());
				throw new HotelException("Failed to Book...");
			}
	        	
	        	
	}        	
	        	
	public double calculateAmount(String room_id,int no_of_days) throws HotelException{
		
		 String selectquery= " select per_night_rate from RoomDetails where room_id=?";
		 
		 try {
				PreparedStatement ps = dbConnection.prepareStatement(selectquery);
				ps.setString(1, room_id);
				ResultSet res = ps.executeQuery();
				
				if(no_of_days<0){
					throw new HotelException("Invalid input");
				}
				else
				{
					double amount=0.0;
					while(res.next()){
						amount=res.getDouble("per_night_rate");
						
					}
					amount=amount*no_of_days;
					ps.setDouble(7, amount);
					ps.executeUpdate();
				}
				
			}catch (SQLException e) {
		              e.printStackTrace();
		              log.error(e.getMessage());
		              throw new HotelException("Failed to get Amount...");
	}

	
	}

}

