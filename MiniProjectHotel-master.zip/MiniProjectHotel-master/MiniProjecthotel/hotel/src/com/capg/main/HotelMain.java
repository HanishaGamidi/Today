package com.capg.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capg.beans.Hotel;
import com.capg.beans.RoomDetails;
import com.capg.dao.AdminDAO;
import com.capg.dao.AdminDAOImpl;
import com.capg.dao.UserDAO;
import com.capg.dao.UserDAOImpl;
import com.capg.exception.HotelException;

import java.sql.PreparedStatement;
import java.util.Date;

public class HotelMain {
	public static void main(String[] args)throws HotelException
	{
		Scanner sc = new Scanner(System.in);
	
	  while(true)
	  {
		  
		    System.out.println("Hotel Bookings Management System\n");
		    System.out.println("________________________________\n");
			System.out.println("1. Login (User/Admin)\n");
			System.out.println("2. Perform Operations\n");
			System.out.println("3. Book Rooms\n");
			System.out.println("2. Exit\n");
			System.out.println("Enter your choice:\n");
			AdminDAO admindao = new AdminDAOImpl();
	        UserDAO userdao = new UserDAOImpl();
			int choice = sc.nextInt();
			if(choice!=4){
			switch(choice)
			{
			
		   
		    case 1:  
		    	    System.out.println("Login ID: \n");
			        String user_id = sc.next(); 
			        
			        System.out.println("Password: \n");
			        String password = sc.next();
			        String role = admindao.userVerification(user_id, password);
			        if(role.equals("User"))
			        {   
			        	System.out.println("\n-----------User Portal------------");
			        	System.out.println("\n 1.Book Rooms\n 2.logout");
			            System.out.println("\n Enter Choice: \n");
			            
			            int opt= sc.nextInt();
			            switch(opt){
			           case 1: System.out.println("\n List of Hotels ");
			                   userdao.retrieveHotelDetails();
			                   System.out.println("\n Enter room Id:");
			                   String room_id= sc.next();
			                   System.out.println("\n User Id:");
			                   String user_id1= sc.next();
			                   System.out.println("\n Enter No of Days:");
			                   int no_of_days=sc.nextInt();
			                   System.out.println("\n Booking From:");
			                   String booking_from = sc.next();
			                   System.out.println("\n Booking To:");
			                   String booking_to = sc.next();
			                   System.out.println("\n Enter No of Adults:");
			                   int no_of_adults = sc.nextInt();
			                   System.out.println("\n Enter No of Children:");
			                   int no_of_children = sc.nextInt();
			                   double amount=userdao.calculateAmount(room_id,no_of_days);
			                   System.out.println("\n Amount:" +amount );
			                   userdao.bookRooms(room_id,user_id1,booking_from,booking_to,no_of_adults,no_of_children,amount);
			                    break;
			            case 2: System.out.println("You have successfully logged out");
			                    break;
			            default: System.out.println("\n invalid option");
			                     
			            }
		    		  
		    		  
			        }else if(role.equals("Admin"))
			        {
			        	System.out.println("\n------------ADMIN Portal--------------");
			        	System.out.println("\n 1.Add Hotels or Rooms\n 2.Update Hotels or Rooms\n 3.Delete Hotels or Rooms");
			        	System.out.println("\n 4.View Reports \n 5.Logout");
			        	int opt2= sc.nextInt();
			        	switch(opt2){
			        	case 1: System.out.println("\n Hotel Id: ");
			        	        String hotel_id=sc.next();
			        	        System.out.println("\n City: ");
			        	        String city= sc.next();
			        	        System.out.println("\n Hotel Name: ");
			        	        String hotel_name= sc.next();
			        	        System.out.println("\n Address: ");
			        	        String address = sc.next();
			        	        System.out.println("\n Description: ");
			        	        String description=sc.next();
			        	        System.out.println("\n Avg_rate_per_night: ");
			        	        double avg_rate_per_night=sc.nextDouble();
			        	        System.out.println("\n Phone_No1: ");
			        	        String phone_no1=sc.next();
			        	        System.out.println("\n Phone_No2: ");
			        	        String phone_no2=sc.next();
			        	        System.out.println("\n Rating: ");
			        	        String rating=sc.next();
			        	        System.out.println("\n Email: ");
			        	        String email=sc.next();
			        	        System.out.println("\n Fax: ");
			        	        String fax=sc.next();
			        	        
			        	        Hotel hotel= new Hotel(hotel);
			        	        
			        	        hotel.setHotel_id(hotel_id);
			        	        hotel.setCity(city);
			        	        hotel.setHotel_name(hotel_name);
			        	        hotel.setAddress(address);
			        	        hotel.setDescription(description);
			        	        hotel.setAvg_rate_per_night(avg_rate_per_night);
			        	        hotel.setPhone_no1(phone_no1);
			        	        hotel.setPhone_no2(phone_no2);
			        	        hotel.setRating(rating);
			        	        hotel.setEmail(email);
			        	        hotel.setFax(fax);
			        	        
			        	        System.out.println("\n Hotel Id: ");
			        	        String hotel_id1= sc.next();
			        	        System.out.println("\n Room Id: ");
			        	        String room_id= sc.next();
			        	        System.out.println("\n Room No: ");
			        	        String room_no= sc.next();
			        	        System.out.println("\n Room Type: ");
			        	        String room_type= sc.next();
			        	        System.out.println("\n Per_night_rate: ");
			        	        double per_night_rate= sc.nextDouble();
			        	        System.out.println("\n Availability: ");
			        	        String availability= sc.next();
			        	        RoomDetails roomdetails= new RoomDetails(roomdetails);
			        	        roomdetails.setHotel_id(hotel_id);
			        	        roomdetails.setRoom_id(room_id);
			        	        roomdetails.setRoom_no(room_no);
			        	        roomdetails.setRoom_type(room_type);
			        	        roomdetails.setPer_night_rate(per_night_rate);
			        	        roomdetails.setAvailability(availability);
			        	        admindao.addDetails(hotel, roomdetails);
			        	        break;
			        	case 2:  System.out.println("\n Update Hotels and Rooms : ");
	        	        		 String name= sc.next();
	        	        		int count = admindao.countapplicants(name);
	 		        	        if(count==0){
	 		        	        //System.out.println("\n Start Date: ");
	 		        	        //System.out.println("\n ENd Date: ");
	 		        	        System.out.println("\n Program Location: ");
	 		        	        String plocation= sc.next();
	 		        	        System.out.println("\n Sessions per week: ");
	 		        	        int sessionspw= sc.nextInt();
	 		        	       // admindao.updateprogram(name, startdate, enddate, sessionspw, plocation);
			        	         }else System.out.println("\n Can't be updated");
	 		        	        break; 
			        	case 3:  System.out.println("\n enter Programname to delete: ");
		        		         String name1= sc.next();
		        		         int count1 = admindao.countapplicants(name1);
	        	                 if(count1==0){
	        	        		 admindao.deleteprogram(name1);
			        	         }else System.out.println("\n Can't be deleted");
	        	                 break;
			        	case 4: System.out.println("\n Enter ProgramId view: ");
			        	        String programid=sc.next();
			        	        System.out.println("\n Enter Status: ");
			        	        String status= sc.next();
			        	        admindao.finallist(programid, status);
			        	        break;
			        	case 5: break;
			        	default: System.out.println("\n invalid choice");
			        }
			      
			       
			   }
			    break;
			    
			case 2: admindao.retrieveprograms();
			        break;
			case 3: System.out.println("\n Enter Details: ");
			        System.out.println("\n FullName: ");
			        String fullname= sc.nextLine();
			        //System.out.println("\n Enter DateOf Birth: ");
			        System.out.println("\n Highest Qualification: ");
			        String qualification= sc.next();
			        System.out.println("\n Goals: ");
			        String goals= sc.nextLine();
			        System.out.println("\n marks obtained: ");
			        int marks= sc.nextInt();
			        System.out.println("\n Email: ");
			        String email= sc.next();
			        System.out.println("\n ProgramId to Apply: ");
			        String programid= sc.next();
			        String status= "Applied";
			        String DOI="NA";
			        //Applicant appl= new Applicant(fullname, dob, qualification, marks, goals, email, programid,status,DOI);
			      //  macdao.createapplicant(appl);
			        break;
			case 4: System.out.println("\n Enter ApplicantId: ");
			        int appid= sc.nextInt();
			        macdao.applicationstatus(appid);
			        break;
			 default: System.out.println("\n Invalid Choice");
			}}else break;
			
		 }
		}
		
		
	}

		    		  
		    		
		
			
		

			
	  

	 
