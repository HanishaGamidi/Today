package com.capg.service;

import com.capg.beans.Hotel;
import com.capg.beans.RoomDetails;
import com.capg.dao.AdminDAO;
import com.capg.dao.AdminDAOImpl;
import com.capg.exception.HotelException;

public class AdminServiceImpl implements AdminService {
	
	AdminDAO admindao;

	
	public String userVerification(String user_id, String password) throws HotelException {
		admindao=new AdminDAOImpl();
		return null;
	}


	public boolean addDetails(Hotel hotel, RoomDetails roomdetails) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean updateDetails(RoomDetails roomdetails) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean deleteDetails(String room_id) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}


	public void viewReports(String booking_id, String user_id, Double amount) throws HotelException {
		// TODO Auto-generated method stub
		
	}

}
