package com.capg.test;

public class UserDAOImpl {

}
