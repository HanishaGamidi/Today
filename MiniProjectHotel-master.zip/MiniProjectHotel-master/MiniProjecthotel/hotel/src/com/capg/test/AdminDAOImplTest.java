package com.capg.test;

public class AdminDAOImplTest {

}
