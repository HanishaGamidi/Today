package com.capgemini.wallet.dao;

import java.util.Map;

import com.capgemini.wallet.bean.Customer;

public class CustomerDao implements ICustomerDao{

	private Map<Integer,Customer> customerData;
	public CustomerDao(Map<Integer, Customer> customerData) 
	{
		super();
		this.customerData = customerData;
	}
	@Override
	public Customer save(Customer customer) {
		if(customerData.containsKey(customer.getMobileNumber()))
		{
			customerData.replace(customer.getMobileNumber(), customer);
		}
		else
			customerData.put(customer.getMobileNumber(), customer);
		return customer;
	}

	@Override
	public Customer findByMobileNumber(int mobileNumber) {
		
		Customer customer=null;
		customer=customerData.get(mobileNumber);
		return customer;
		
	}

	/*@Override
	public Customer updateCustomerWalletBalance(int mobileNumber, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}*/
	
	

}
