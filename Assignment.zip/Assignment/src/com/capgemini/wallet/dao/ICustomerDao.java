package com.capgemini.wallet.dao;

import com.capgemini.wallet.bean.Customer;

public interface ICustomerDao {
	
	public Customer save(Customer customer);

	public Customer findByMobileNumber(int mobileNumber);

	//public Customer updateCustomerWalletBalance(int mobileNumber,BigDecimal amount);


}
