package com.capgemini.wallet.bean;

public class Customer {
	
	
	private String customerName;
	private int mobileNumber;
	private Wallet wallet;
	
	public Customer(String customerName, int mobileNumber, Wallet wallet) {
		super();
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.wallet = wallet;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", mobileNumber=" + mobileNumber + ", wallet=" + wallet + "]";
	}

}
