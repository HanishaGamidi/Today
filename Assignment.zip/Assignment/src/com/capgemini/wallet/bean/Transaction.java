package com.capgemini.wallet.bean;

import java.math.BigDecimal;
import java.util.Date;

public class Transaction {
	
	private Date transactionDate;
	private int transactionId;
	private String description;
	private BigDecimal amount;
	private BigDecimal balance;
	
	
	public Transaction(Date transactionDate, int transactionId, String description, BigDecimal amount,
			BigDecimal balance) {
		super();
		this.transactionDate = transactionDate;
		this.transactionId = transactionId;
		this.description = description;
		this.amount = amount;
		this.balance = balance;
	}
	
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	
	


}
