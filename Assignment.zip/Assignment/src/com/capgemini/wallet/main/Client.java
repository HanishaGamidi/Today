package com.capgemini.wallet.main;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.wallet.bean.Customer;
import com.capgemini.wallet.service.CustomerService;
import com.capgemini.wallet.service.ICustomerService;

public class Client {
	
	
	public static void main(String args[]){
		ICustomerService customerService;
		Map<Integer, Customer> customerData=new HashMap<Integer, Customer>();
		
		{
			//System.out.println("Welcome to Payment Wallet Application");
			customerService=new CustomerService(customerData);
		}
		//String mobileNumber;

		Customer customer ;

		
		
		Customer customer1=customerService.createAccount("Hanisha",1234567890,new BigDecimal(6000));
		System.out.println("Thank you,Your account has been created successfully");
		Customer customer2=customerService.createAccount("Anjani",1876543290,new BigDecimal(5000));
		System.out.println("Thank you,Your account has been created successfully");
		Customer customer3=customerService.createAccount("Roshini",1357908642,new BigDecimal(4000));
		System.out.println("Thank you,Your account has been created successfully");
		Customer customer4=customerService.createAccount("Manisha",1468097536,new BigDecimal(3000));
		System.out.println("Thank you,Your account has been created successfully");
		Customer customer5=customerService.createAccount("Harini",2123456789,new BigDecimal(2000));
		System.out.println("Thank you,Your account has been created successfully");
		
		customer=customerService.showBalance(1234567890);
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance(1876543290);
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance(1357908642);
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance(1468097536);
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
		customer=customerService.showBalance(2123456789);
		System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
}

}