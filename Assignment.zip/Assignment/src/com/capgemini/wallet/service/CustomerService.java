package com.capgemini.wallet.service;

import java.math.BigDecimal;
import java.util.Map;

import com.capgemini.wallet.bean.Customer;
import com.capgemini.wallet.bean.Wallet;
import com.capgemini.wallet.dao.CustomerDao;
import com.capgemini.wallet.dao.ICustomerDao;
import com.capgemini.wallet.exception.InvalidInputException;


public class CustomerService implements ICustomerService{
	
	private ICustomerDao customerDao;
	public CustomerService(Map<Integer, Customer> customerData){
		customerDao= new CustomerDao(customerData);
	}
	public CustomerService(ICustomerDao customerDao) 
	{
		super();
		this.customerDao = customerDao;
	}


	@Override
	public Customer createAccount(String customerName,int mobileNumber,BigDecimal balance) {
        Customer customer=null;
		
		if(isValidName(customerName) && isValidMobile(mobileNumber) && isValidamount(balance))
		{
		customer=new Customer(customerName,mobileNumber,new Wallet(balance));
		if(customerDao.findByMobileNumber(mobileNumber) != null)
			throw new InvalidInputException("The account with mobile Number "+ mobileNumber+" is already created");
		customerDao.save(customer);
		}
		
		return customer;	
	}

	/*@Override
	public Customer fundTransfer(int mobileNumber, int receiverMobileNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer depositAmount(int mobileNumber, BigDecimal balance) {
		// TODO Auto-generated method stub
		return null;
	}*/

	@Override
	public Customer showBalance(int mobileNumber) {
		Customer customer=null;
		if(isValidMobile(mobileNumber))
		{
		  customer=customerDao.findByMobileNumber(mobileNumber);
		}
		if(customer == null)
			throw new InvalidInputException("The mobile Number You Entered is Not having Payment Wallet Account");
		return customer;
		

	}

	/*@Override
	public Customer showTransactions(int mobileNumber) {
		// TODO Auto-generated method stub
		return null;
	}
*/
	public boolean isValidName(String customerName) throws InvalidInputException 
	{
		if( customerName == null)
			throw new InvalidInputException( "Sorry, Customer Name is null" );
		
		if( customerName.trim().isEmpty() )
			throw new InvalidInputException( "Sorry, customer Name is Empty" );
		
		return true;
	}

	public boolean isValidMobile(int mobileNumber)throws InvalidInputException
	{
		if( mobileNumber == 0||  isPhoneNumberInvalid( mobileNumber ))
			throw new InvalidInputException( "Sorry, Phone Number "+mobileNumber+" is invalid"  );
		
		return true;
	}

	public boolean isValidamount(BigDecimal balance)throws InvalidInputException
	{
		if( balance == null || isAmountInvalid( balance ) )
			throw new InvalidInputException( "Balance is invalid" );

		return true;
	}

	public boolean isAmountInvalid(BigDecimal amount) 
	{
		
		if( amount.compareTo(new BigDecimal(0)) < 0) 
		{
			return true;
		}		
		else 
			return false;
	}

	public static boolean isPhoneNumberInvalid( int mobileNumber )
	{
		if(String.valueOf(mobileNumber).matches("[1-9][0-9]{9}")) 
		{
			return false;
		}		
		else 
			return true;
	}

}
