package com.capgemini.wallet.service;

import java.math.BigDecimal;

import com.capgemini.wallet.bean.Customer;

public interface ICustomerService {
	
	public Customer createAccount(String customerName,int mobileNumber, BigDecimal balance);
	//public Customer fundTransfer(int mobileNumber, int receiverMobileNumber);
	//public Customer depositAmount(int mobileNumber, BigDecimal balance);
	public Customer showBalance(int mobileNumber);
	//public Customer showTransactions(int mobileNumber);
	



}
